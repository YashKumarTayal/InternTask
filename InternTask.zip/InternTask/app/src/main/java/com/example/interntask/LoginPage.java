package com.example.interntask;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.MalformedURLException;
import java.net.URI;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.net.URLConnection;
import java.net.URLEncoder;
import java.text.BreakIterator;

public class LoginPage extends AppCompatActivity {

    ImageView loginbtn;
    EditText phone,pass;
    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);
        phone=findViewById(R.id.phone_number);
        pass=findViewById(R.id.password);
        loginbtn = findViewById(R.id.login);
        loginbtn.setOnClickListener(new View.OnClickListener() {
            String Phone, Pass;

            @Override
            public void onClick(View view) {
                if(phone.getText().toString().equals("9999999999") && pass.getText().toString().equals("0123456789")) {
                    Toast.makeText(LoginPage.this,"Booking Successfull",Toast.LENGTH_SHORT).show();
                }else{
                    Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://mekvahan.com/api/android_intern_task"));
                    startActivity(intent);
                    Toast.makeText(LoginPage.this,"Logged in Failed",Toast.LENGTH_SHORT).show();
                }
            }
});
    }
}