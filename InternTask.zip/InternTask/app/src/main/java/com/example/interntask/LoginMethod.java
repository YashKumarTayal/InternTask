package com.example.interntask;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Paint;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class LoginMethod extends AppCompatActivity {
    ImageView loginbutton1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_method);
    loginbutton1 = findViewById(R.id.login_button1);
    loginbutton1.setOnClickListener(new View.OnClickListener() {
        @Override
        public void onClick(View view) {
            Intent intent = new Intent(LoginMethod.this, LoginPage.class);
            startActivity(intent);
        }
    });
    }
}